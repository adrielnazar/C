float fahrenheit(float);
float valor(float, float);

