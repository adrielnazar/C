#include "calculo.h"

float fahrenheit(float celciu) {
	float fahrenheit;
	
    fahrenheit = celciu*1.8 + 32;
	
	return fahrenheit;
}

float valor(float reais, float dolares) {
	float valor;
	
	valor = reais/dolares;
	
	return valor;
}
