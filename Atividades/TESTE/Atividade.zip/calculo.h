#ifndef CALCULO_H
#define CALCULO_H

float fahrenheit(float celciu);
float valor(float reais, float dolares);

#endif
